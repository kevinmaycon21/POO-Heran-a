class Animal:
    def __init__(self,nome,cor):
        self.nome=nome
        self.cor=cor
    def fazer_som(self, som):
            print(f"O {self.nome} faz {som} ")

meu_pet= Animal('Porco','rosa')
meu_pet.fazer_som('oinc oinc')

class Gato(Animal):
    def miar(self):
        self.fazer_som('Miau miau')

meu_gato=Gato('Rex','preto')
meu_gato.miar()

class Vaca(Animal):
    def mugir(self):
        self.fazer_som('Muuuu')
minha_vaca=Vaca('mimosa','marron')
minha_vaca.mugir()

class Coelho(Animal):
    def barulho(self):
        self.fazer_som('quic quic')
meu_coelho=Coelho('Verc','Red')
meu_coelho.barulho()

